---
title: "(PDF) Foucault 1991 Governmentality"
description: "(pdf) restructuring of social and political theory in education"
date: "2022-08-30"
categories:
- "image"
images:
- "https://imgv2-1-f.scribdassets.com/img/document/31184449/original/ae582fd60d/1584566944?v=1"
featuredImage: "https://i1.rgstatic.net/publication/229548724_Restructuring_of_Social_and_Political_Theory_in_Education_Foucault_and_a_social_epistemology_of_school_practices/links/5e99ad7e299bf13079a20f3f/largepreview.png"
featured_image: "https://imgv2-1-f.scribdassets.com/img/document/31184449/original/ae582fd60d/1584566944?v=1"
image: "https://imgv2-1-f.scribdassets.com/img/document/31184449/original/ae582fd60d/1584566944?v=1"
---

If you are searching about (PDF) Governmentality, state culture and indigenous rights you've visit to the right place. We have 3 Pictures about (PDF) Governmentality, state culture and indigenous rights like (PDF) Restructuring of Social and Political Theory in Education, (PDF) Governmentality, state culture and indigenous rights and also Michel Foucault: A diskurzus rendje. Read more:

## (PDF) Governmentality, State Culture And Indigenous Rights

![(PDF) Governmentality, state culture and indigenous rights](https://i1.rgstatic.net/publication/292498288_Governmentality_state_culture_and_indigenous_rights/links/577eee3b08ae5f367d33e434/largepreview.png "(pdf) restructuring of social and political theory in education")

<small>www.researchgate.net</small>

Indigenous governmentality rights culture state. Michel foucault: a diskurzus rendje

## Michel Foucault: A Diskurzus Rendje

![Michel Foucault: A diskurzus rendje](https://imgv2-1-f.scribdassets.com/img/document/31184449/original/ae582fd60d/1584566944?v=1 "(pdf) governmentality, state culture and indigenous rights")

<small>www.scribd.com</small>

Indigenous governmentality rights culture state. Epistemology foucault

## (PDF) Restructuring Of Social And Political Theory In Education

![(PDF) Restructuring of Social and Political Theory in Education](https://i1.rgstatic.net/publication/229548724_Restructuring_of_Social_and_Political_Theory_in_Education_Foucault_and_a_social_epistemology_of_school_practices/links/5e99ad7e299bf13079a20f3f/largepreview.png "Epistemology foucault")

<small>www.researchgate.net</small>

Michel foucault: a diskurzus rendje. Indigenous governmentality rights culture state

Epistemology foucault. Michel foucault: a diskurzus rendje. (pdf) restructuring of social and political theory in education
