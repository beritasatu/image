---
title: "Waterlogging in Guwahaty City- Disaster or Problem"
description: "Delhi’s new plan to tackle water scarcity"
date: "2021-11-12"
categories:
- "image"
images:
- "https://images.indianexpress.com/2016/07/waterlogging-759.jpg?resize=450"
featuredImage: "https://urbanupdate.in/wp-content/uploads/2019/07/Water-Crisis_Reuters-2.jpg"
featured_image: "https://i1.rgstatic.net/publication/283582359_AICTE-NEQIP_sponsored_two_days_International_seminar_at_Guwahaty_on_Diaster_Management_-_issues_and_challenges_GUWAHATY_CITY_WATERLOGGING_-DISASTER_OR_PROBLEM/links/5640f3ae08ae24cd3e40ce3f/largepreview.png"
image: "https://static.toiimg.com/thumb/msid-64940247,width-1070,height-580,imgsize-1111356,resizemode-75,overlay-toi_sw,pt-32,y_pad-40/photo.jpg"
---

If you are looking for Description of the Course and Length of Bharalu, Bahini, Basistha you've visit to the right web. We have 35 Pics about Description of the Course and Length of Bharalu, Bahini, Basistha like Waterlogging in Guwahaty City- Disaster or Problem | Drainage Basin | Flood, (PDF) AICTE-NEQIP sponsored two days International seminar at Guwahaty and also Karnataka rains: Flood situation worsens in Shivamogga, Chikkamagaluru. Read more:

## Description Of The Course And Length Of Bharalu, Bahini, Basistha

![Description of the Course and Length of Bharalu, Bahini, Basistha](https://www.researchgate.net/profile/Prashanta-Bordoloi-2/publication/283582359/figure/download/tbl1/AS:391445115621380@1470339196538/1-Description-of-the-Course-and-Length-of-Bharalu-Bahini-Basistha-Morabharalu-and.png "Till when will we let our cities drown?")

<small>www.researchgate.net</small>

Waterlogging: social media flooded with complaints, bmc disaster. Chiplun floods partly man-made disaster: ratnagiri collector

## Another Electrocution Death In City - Telegraph India

![Another electrocution death in city - Telegraph India](https://s3.ap-south-1.amazonaws.com/cms-abp-prod-media/library/THE_TELEGRAPH/mig/media/images/2017/06/23/23regGilrs.jpg "Guwahati assam contribution rediff news18")

<small>www.telegraphindia.com</small>

Delhi’s new plan to tackle water scarcity. Flooding rains

## Guwahati Gets An Experimental Flood Warning System - The Wire Science

![Guwahati Gets an Experimental Flood Warning System - The Wire Science](https://cdn.thewire.in/wp-content/uploads/2020/07/27133355/2020-07-27T074417Z_1_LYNXNPEG6Q0DS_RTROPTP_4_HEALTH-CORONAVIRUS-INDIA-PLASMAf-1110x754.jpg "Karnataka rains: flood situation worsens in shivamogga, chikkamagaluru")

<small>science.thewire.in</small>

Waterlogging flooded dept indianexpress. Chiplun floods partly man-made disaster: ratnagiri collector

## The Bharalu River System | Download Scientific Diagram

![The Bharalu River System | Download Scientific Diagram](https://i1.rgstatic.net/ii/profile.image/285910198439936-1445177711352_Q128/Prashanta-Bordoloi-2.jpg "Guwahati diaster aicte waterlogging")

<small>www.researchgate.net</small>

Description of the course and length of bharalu, bahini, basistha. Government ignored its own disaster report despite warning that j&amp;k is

## Northeast Flood: Lakhs Marooned As Monsoon Hits North East | Guwahati

![Northeast flood: Lakhs marooned as monsoon hits North East | Guwahati](https://timesofindia.indiatimes.com/img/64582076/Master.jpg "Dhaka waterlogging")

<small>timesofindia.indiatimes.com</small>

Water crisis in guwahati city: how wise is it to let it go waste. Till when will we let our cities drown?

## Water Crisis In Guwahati City: How Wise Is It To Let It Go Waste

![Water Crisis In Guwahati City: How Wise Is It To Let It Go Waste](https://www.sentinelassam.com/wp-content/uploads/2019/03/111-1.jpg "Water emergency: maharashtra&#039;s water crisis wrecking livelihoods of")

<small>www.sentinelassam.com</small>

Population growth in guwahati vis-à-vis india, assam and kamrup. Guwahati diaster aicte waterlogging

## Till When Will We Let Our Cities Drown? | TERI

![Till when will we let our cities drown? | TERI](https://www.teriin.org/sites/default/files/inline-images/cities-drown.jpg "Flood villages due odisha waterlogging slows fight moon release water died far total under state gram panchayats massive blocks hit")

<small>www.teriin.org</small>

Heavy rains cause waterlogging, affect vehicular movement in delhi. Time8 news

## Kerala: Heavy Rain Likely As Cyclone Moves Over Arabian Sea | Kochi

![Kerala: Heavy rain likely as cyclone moves over Arabian Sea | Kochi](https://static.toiimg.com/thumb/msid-71829073,width-1070,height-580,imgsize-563616,resizemode-75,overlay-toi_sw,pt-32,y_pad-40/photo.jpg "Why waterlogging in dhaka city")

<small>timesofindia.indiatimes.com</small>

Waterlogging affected rains vehicular alaknanda. Marooned lakhs

## Delhi’s New Plan To Tackle Water Scarcity - Urban Update

![Delhi’s new plan to tackle water scarcity - Urban Update](https://urbanupdate.in/wp-content/uploads/2019/07/Water-Crisis_Reuters-2-200x200.jpg "Another electrocution death in city")

<small>urbanupdate.in</small>

Wise waste let guwahati crisis water sentinelassam sentinel desk digital. Electrocution guwahati waterlogged

## Waterlogging In Mumbai: Rain And Waterlogging In Mumbai Stall Travel

![waterlogging in Mumbai: Rain and waterlogging in Mumbai stall travel](https://static.toiimg.com/thumb/msid-64940247,width-1070,height-580,imgsize-1111356,resizemode-75,overlay-toi_sw,pt-32,y_pad-40/photo.jpg "Guwahati predict time8")

<small>timesofindia.indiatimes.com</small>

Description of the course and length of bharalu, bahini, basistha. Heavy rain, waterlogging again brings delhi-ncr to a standstill

## TIME8 News | Guwahati Now Has An Automated Early Warning System To

![TIME8 News | Guwahati now has an Automated Early Warning System to](https://www.time8.in/wp-content/uploads/2020/08/guwahati-flood.jpg "Climbs recede toll waters livemint")

<small>www.time8.in</small>

Till when will we let our cities drown?. Waterlogging flooded dept indianexpress

## City Hit By Water Shortage Due To Damaged Main – Kaieteur News

![City hit by water shortage due to damaged main – Kaieteur News](https://www.kaieteurnewsonline.com/images/2019/08/GWI-1.jpg "Guwahati assam contribution rediff news18")

<small>www.kaieteurnewsonline.com</small>

Kerala: heavy rain likely as cyclone moves over arabian sea. Till when will we let our cities drown?

## Waste Water Generation In Guwahati | Download Table

![Waste Water Generation in Guwahati | Download Table](https://www.researchgate.net/profile/Prashanta_Bordoloi/publication/283582359/figure/fig2/AS:391445111427085@1470339195905/3-The-Bharalu-River-System_Q640.jpg "Waterlogging: social media flooded with complaints, bmc disaster")

<small>www.researchgate.net</small>

Wise waste let guwahati crisis water sentinelassam sentinel desk digital. Water emergency: maharashtra&#039;s water crisis wrecking livelihoods of

## Heavy Rain, Waterlogging Again Brings Delhi-NCR To A Standstill | Delhi

![Heavy rain, waterlogging again brings Delhi-NCR to a standstill | Delhi](https://static.toiimg.com/thumb/msid-53940315,width-1070,height-580,imgsize-28645,resizemode-75,overlay-toi_sw,pt-32,y_pad-40/photo.jpg "Basistha bahini")

<small>timesofindia.indiatimes.com</small>

Gujarat rain: widespread rains lash gujarat, more likely; 13 ndrf teams. City hit by water shortage due to damaged main – kaieteur news

## Why Waterlogging In Dhaka City - Bangladesh Post

![Why waterlogging in Dhaka city - Bangladesh Post](https://bangladeshpost.net/webroot/uploads/featureimage/2019-07/5d28a3b1ae63d.jpg "Guwahati waste")

<small>bangladeshpost.net</small>

The bharalu river system. Waterlogging flooded dept indianexpress

## Guwahati’s Contribution To Its Very Own ‘Artificial Floods’ - The Sentinel

![Guwahati’s contribution to its very own ‘Artificial Floods’ - The Sentinel](https://www.sentinelassam.com/wp-content/uploads/2018/06/Flood-1-1-990x646.jpg "Marooned lakhs")

<small>www.sentinelassam.com</small>

Basistha bahini. City hit by water shortage due to damaged main – kaieteur news

## The Bharalu River System | Download Scientific Diagram

![The Bharalu River System | Download Scientific Diagram](https://www.researchgate.net/profile/Prashanta-Bordoloi-2/publication/283582359/figure/tbl3/AS:391445115621382@1470339196615/3-Population-Growth-in-Guwahati-vis-a-vis-India-Assam-and-Kamrup_Q640.jpg "Waterlogging: social media flooded with complaints, bmc disaster")

<small>www.researchgate.net</small>

Description of the course and length of bharalu, bahini, basistha. Water emergency: maharashtra&#039;s water crisis wrecking livelihoods of

## Delhi: Several Areas Of The City Suffer From Waterlogging Due To Heavy

![Delhi: Several Areas Of The City Suffer From Waterlogging Due To Heavy](https://i.ytimg.com/vi/hhVkETOTdSI/maxresdefault.jpg "Disaster floods flash susceptible ignored despite highly warning government report srinagar development aerial own its livelihood infrastructure lands creation focus")

<small>www.youtube.com</small>

Climbs recede toll waters livemint. Delhi’s new plan to tackle water scarcity

## Water Scarcity In India – Ground Water Crisis – INDEPENDENT FOURTH ESTATE

![Water Scarcity in India – Ground Water Crisis – INDEPENDENT FOURTH ESTATE](https://indianews165785300.files.wordpress.com/2020/12/ground.jpg?w=1024 "Why waterlogging in dhaka city")

<small>indianews165785300.wordpress.com</small>

Waterlogging flooded dept indianexpress. Guwahati predict time8

## Government Ignored Its Own Disaster Report Despite Warning That J&amp;K Is

![Government ignored its own disaster report despite warning that J&amp;K is](https://i.dailymail.co.uk/i/pix/2014/09/11/1410473036128_wps_2_JAVED_jpg.jpg "Diaster disaster aicte seminar waterlogging challenges sponsored issues problem management international days")

<small>www.dailymail.co.uk</small>

The bharalu river system. Description of the course and length of bharalu, bahini, basistha

## Two Die As Rains Cause Urban Flooding In Capital - Newspaper - DAWN.COM

![Two die as rains cause urban flooding in capital - Newspaper - DAWN.COM](https://i.dawn.com/primary/2021/07/6101baae3daaf.jpg "Electrocution guwahati waterlogged")

<small>www.dawn.com</small>

(pdf) aicte-neqip sponsored two days international seminar at guwahaty. Description of the course and length of bharalu, bahini, basistha

## Waterlogging In Guwahaty City- Disaster Or Problem | Drainage Basin | Flood

![Waterlogging in Guwahaty City- Disaster or Problem | Drainage Basin | Flood](https://imgv2-2-f.scribdassets.com/img/document/298267563/original/51518e7de9/1588680272?v=1 "Climbs recede toll waters livemint")

<small>www.scribd.com</small>

Waterlogging flooded dept indianexpress. Waterlogging in mumbai: rain and waterlogging in mumbai stall travel

## Gujarat Floods: Death Toll Climbs To 213 As Waters Recede

![Gujarat floods: Death toll climbs to 213 as waters recede](https://images.livemint.com/rf/Image-621x414/LiveMint/Period2/2017/08/01/Photos/Processed/gujaratfloods-kQmG--621x414@LiveMint.jpg "Waterlogging in mumbai: rain and waterlogging in mumbai stall travel")

<small>www.livemint.com</small>

Water maharashtra crisis. Waterlogging in mumbai: rain and waterlogging in mumbai stall travel

## Chiplun Floods Partly Man-made Disaster: Ratnagiri Collector | Pune

![Chiplun floods partly man-made disaster: Ratnagiri collector | Pune](https://static.toiimg.com/thumb/msid-84665469,width-1070,height-580,imgsize-91472,resizemode-75,overlay-toi_sw,pt-32,y_pad-40/photo.jpg "Climbs recede toll waters livemint")

<small>timesofindia.indiatimes.com</small>

Till when will we let our cities drown?. Northeast flood: lakhs marooned as monsoon hits north east

## Karnataka Rains: Flood Situation Worsens In Shivamogga, Chikkamagaluru

![Karnataka rains: Flood situation worsens in Shivamogga, Chikkamagaluru](https://static.toiimg.com/thumb/msid-70557464,width-1070,height-580,imgsize-682484,resizemode-75,overlay-toi_sw,pt-32,y_pad-40/photo.jpg "Guwahati experimental")

<small>timesofindia.indiatimes.com</small>

Waterlogging in guwahaty city- disaster or problem. Waste water generation in guwahati

## Full Moon Day Slows Flood Water Release, Odisha Villages Fight

![Full moon day slows flood water release, Odisha villages fight](https://www.hindustantimes.com/rf/image_size_960x540/HT/p2/2020/09/02/Pictures/villagers-gathered-district-flooded-river-bhargavi-khordha_a05fe7d4-ecfb-11ea-83c1-09a59be16170.jpg "(pdf) aicte-neqip sponsored two days international seminar at guwahaty")

<small>www.hindustantimes.com</small>

Waterlogging affected rains vehicular alaknanda. Dhaka waterlogging

## Heavy Rains Cause Waterlogging, Affect Vehicular Movement In Delhi

![Heavy rains cause waterlogging, affect vehicular movement in Delhi](https://aniportalimages.s3.amazonaws.com/media/details/E7RsD_JUYAE4puK.jpg "City hit by water shortage due to damaged main – kaieteur news")

<small>www.sify.com</small>

Waterlogging: social media flooded with complaints, bmc disaster. Bahini guwahati wards wetland basistha

## 2 : The Natural Drainage Density In Different Wards Of Guwahati City

![2 : The natural drainage density in different wards of Guwahati city](https://www.researchgate.net/profile/Prashanta_Bordoloi/publication/283582359/figure/tbl2/AS:391445115621381@1470339196569/2-Monthly-Rainfall-mm-in-Guwahati-from-2008-to-2012_Q320.jpg "Electrocution guwahati waterlogged")

<small>www.researchgate.net</small>

Gujarat floods: death toll climbs to 213 as waters recede. Waste water generation in guwahati

## Gujarat Rain: Widespread Rains Lash Gujarat, More Likely; 13 NDRF Teams

![Gujarat Rain: Widespread rains lash Gujarat, more likely; 13 NDRF teams](https://static.toiimg.com/thumb/msid-77545316,width-1070,height-580,imgsize-104765,resizemode-75,overlay-toi_sw,pt-32,y_pad-40/photo.jpg "Why waterlogging in dhaka city")

<small>timesofindia.indiatimes.com</small>

Guwahati predict time8. Waste water generation in guwahati

## Waste Water Generation In Guwahati | Download Table

![Waste Water Generation in Guwahati | Download Table](https://www.researchgate.net/profile/Prashanta_Bordoloi/publication/283582359/figure/tbl5/AS:391445115621385@1470339196840/1-Waste-Water-Generation-in-Guwahati.png "Water scarcity in india – ground water crisis – independent fourth estate")

<small>www.researchgate.net</small>

Another electrocution death in city. Government ignored its own disaster report despite warning that j&amp;k is

## Population Growth In Guwahati Vis-à-vis India, Assam And Kamrup

![Population Growth in Guwahati vis-à-vis India, Assam and Kamrup](https://www.researchgate.net/profile/Prashanta-Bordoloi-2/publication/283582359/figure/fig3/AS:391445115621376@1470339196191/4-Elevations-of-the-Bharalu-River-Catchment-Area-in-metres-above-MSL-The-annual_Q320.jpg "The bharalu river system")

<small>www.researchgate.net</small>

Main shortage damaged due hit water prepare workers install. Delhi’s new plan to tackle water scarcity

## Delhi’s New Plan To Tackle Water Scarcity - Urban Update

![Delhi’s new plan to tackle water scarcity - Urban Update](https://urbanupdate.in/wp-content/uploads/2019/07/Water-Crisis_Reuters-2.jpg "Gujarat floods: death toll climbs to 213 as waters recede")

<small>urbanupdate.in</small>

Population growth in guwahati vis-à-vis india, assam and kamrup. Till when will we let our cities drown?

## Waterlogging: Social Media Flooded With Complaints, BMC Disaster

![Waterlogging: Social media flooded with complaints, BMC disaster](https://images.indianexpress.com/2016/07/waterlogging-759.jpg?resize=450 "Marooned lakhs")

<small>indianexpress.com</small>

The bharalu river system. Wise waste let guwahati crisis water sentinelassam sentinel desk digital

## Water Emergency: Maharashtra&#039;s Water Crisis Wrecking Livelihoods Of

![Water Emergency: Maharashtra&#039;s Water Crisis Wrecking Livelihoods Of](https://i.ytimg.com/vi/vf1lYop6XSM/maxresdefault.jpg "Waterlogging flooded dept indianexpress")

<small>www.youtube.com</small>

Waterlogging affected rains vehicular alaknanda. Delhi: several areas of the city suffer from waterlogging due to heavy

## (PDF) AICTE-NEQIP Sponsored Two Days International Seminar At Guwahaty

![(PDF) AICTE-NEQIP sponsored two days International seminar at Guwahaty](https://i1.rgstatic.net/publication/283582359_AICTE-NEQIP_sponsored_two_days_International_seminar_at_Guwahaty_on_Diaster_Management_-_issues_and_challenges_GUWAHATY_CITY_WATERLOGGING_-DISASTER_OR_PROBLEM/links/5640f3ae08ae24cd3e40ce3f/largepreview.png "Electrocution guwahati waterlogged")

<small>www.researchgate.net</small>

Waterlogging: social media flooded with complaints, bmc disaster. Bahini guwahati wards wetland basistha

Electrocution guwahati waterlogged. 2 : the natural drainage density in different wards of guwahati city. (pdf) aicte-neqip sponsored two days international seminar at guwahaty
